<?php

	/*
		FILE TO DOWNLOAD ON PHP SERVER
		- require global internet access eg. https://[your domain or ip, some path...]/server.php
	
		usage:
		
		./server.php?w=[MAC_ADDRESS:IP_ADDRESS]&auth=[MD5_HASH]
		
		MAC_ADDRESS and IP_ADDRESS= of the computer on your android device network to send WOL (eg. 90b11c8cba77:10.10.10.100) - Notice: MAC format without any delimeters
		MD5_HASH = MD5 of [PIN][MAC_ADDRESS]:[IP_ADDRESS]
		
		./server.php?test - will show request without processing time and updateting request file. Also it will show last update time of request file. Can be used to check if something is watching requests.
	*/

	
	define('PIN', 0000); //same password as in android App
	define('REQUEST_CONTAINER', 'requests.wol');//file to store requests
	define('DEBUG', 0);//1=ON, 0=OFF
	
	define('REQUEST_TIMEOUT', 600);//seconds
	
	error_reporting(E_ALL^E_NOTICE);
	
	function validate($w='') {
		$auth = '';
		if (isset($_GET['auth'])) {
			$auth = strval($_GET['auth']);
		}
		
		if (!empty($w) && strpos($w,':')) {
			list($mac, $ip) = explode(':',$w);
			
			if (strlen($mac) == 12) {
				$macFormatted = '';
				for ($i=0;$i<6;$i++) {
					$macFormatted .= substr($mac, 2*$i, 2);
					if ($i<5) {
					    $macFormatted .='-';
					}
				}
				
				if (!filter_var($macFormatted, FILTER_VALIDATE_MAC) || !filter_var($ip, FILTER_VALIDATE_IP)) {
					$w = '';
					debug('Validation of MAC='.$macFormatted.' or IP='.$ip.' failed...');
				}
			}
		}
		
		if (empty($w) || !strpos($w,':') || strlen($w) < 20 || strcasecmp(md5(PIN.$w), $auth) != 0) {
			debug('Auth failed for '.$w);
			die('AUTH OR FORMAT FAILED!');
		}
	}
	
	if (isset($_GET['w'])) {
		
		$w = strtolower(strval($_GET['w']));
		validate($w);
		
		echo add($w);
		
	} else {
		
		echo readRequests();
	}
	
	function add($newW) {
		
		debug('Adding request for '.$newW);		
		
		$now = time();
		
		$array = array($now => $newW);
		
		if (file_exists(REQUEST_CONTAINER)) {
			$f = file_get_contents(REQUEST_CONTAINER);
			if (!empty($f)) {
				$oldArray = unserialize($f);
				if (is_array($oldArray)) {
					foreach ($oldArray as $t => $w) {
						if ($t + REQUEST_TIMEOUT < $now) {
							debug('Request for '.$w.' has timeout.');
						} else {
							debug('Request for '.$w.' is still valid.');
							$array[$t] = $w;
						}
					}
				}
			}
		}
		
		file_put_contents(REQUEST_CONTAINER, serialize($array), LOCK_EX);
		
		return 'OK';
	}
	
	function readRequests() {
		
		debug('Got read requests command.');
				
		$f='';
		if (file_exists(REQUEST_CONTAINER)) {
			$f = file_get_contents(REQUEST_CONTAINER);
			
			if (isset($_GET['test'])) {
				echo date("Y-m-d H:i:s", filemtime(REQUEST_CONTAINER)).'<br/>';
			}
		}
		
		if (empty($f)) {
			return 'OK';//nothing to do...
		}
		
		unset($array);
		
		$now = time();
		
		$oldArray = unserialize($f);
		if (is_array($oldArray)) {
			foreach ($oldArray as $t => $w) {
				if ($t + REQUEST_TIMEOUT < $now) {
					debug('Request for '.$w.' has timeout.');
				} else {
					debug('Request for '.$w.' is still valid.');
					$array[$t] = $w;
				}
			}
		}
		
		if (!isset($_GET['test'])) {
			if (empty($array)) {
				@unlink(REQUEST_CONTAINER);
				return 'OK';
			}
			
			file_put_contents(REQUEST_CONTAINER, serialize($array), LOCK_EX);
		}
		return implode(';',array_values($array));
		
	}
	
	function debug($text) {
		if (DEBUG == 1) {
			$c='['.date("Y-m-d H:i:s").']: '.$text."\n";
			
			$file='./debug.txt';
			if (!$h = fopen($file, 'a+')) return;
			stream_set_write_buffer($h, 0);
			if (fwrite($h, $c) === FALSE) return;
			@fclose($h);
		}
	}

?>
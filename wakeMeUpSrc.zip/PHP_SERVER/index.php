<?php
	
	//TEST
	
	define('PIN', 0000);
	
	$w = '90b11c8cba77:10.10.10.200';
	$auth = md5(PIN.strtolower($w));
	
	echo 'Adding '.$w.'<br/>';
	echo file_get_contents('https://[YOUR DOMAIN]/server.php?w='.$w.'&auth='.$auth);

?>
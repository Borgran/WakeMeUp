package averta.pl.wakemeup;



import android.content.Intent;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.util.Log;

import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class SendWol {

    private static final int PORT = 9;


    public SendWol() {
    }

    public boolean callMany(String many) {
        if (many == null || many.isEmpty()) return true;

        if (many.contains(";")) {
            String[] results = many.split(";");

            boolean isAllSuccess = true;

            for(String mac : results) {
                if (!this.call(mac)) {
                    isAllSuccess = false;
                }
            }

            return isAllSuccess;

        } else {
            return this.call(many);
        }
    }

    private boolean call(String single) {
         try {
             String[] data = single.split(":");
             String macAddress = data[0];
             String ipAddress = data[1];

             byte[] macBytes = getMacBytes(macAddress);
             byte[] bytes = new byte[6 + 16 * macBytes.length];
             for (int i = 0; i < 6; i++) {
                 bytes[i] = (byte) 0xff;
             }
             for (int i = 6; i < bytes.length; i += macBytes.length) {
                 System.arraycopy(macBytes, 0, bytes, i, macBytes.length);
             }

             InetAddress address = InetAddress.getByName(ipAddress);
             DatagramPacket packet = new DatagramPacket(bytes, bytes.length, address, PORT);
             DatagramSocket socket = new DatagramSocket();
             socket.send(packet);
             socket.close();

             return true;
        } catch (Exception e) {
             Log.i("SendWol", "Error");
        }

        return false;
    }

    private static byte[] getMacBytes(String macStr) throws IllegalArgumentException {
        byte[] bytes = new byte[6];

        try {
            for (int i = 0; i < 6; i++) {
                bytes[i] = (byte) Integer.parseInt(macStr.substring(2*i,2*i+2), 16);
            }
        } catch (Exception e) {
            throw new IllegalArgumentException("Invalid hex digit in MAC address.");
        }

        return bytes;
    }


}

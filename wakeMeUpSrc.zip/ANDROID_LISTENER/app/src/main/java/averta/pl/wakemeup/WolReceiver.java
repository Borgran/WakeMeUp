package averta.pl.wakemeup;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

public class WolReceiver extends BroadcastReceiver {
    public static final int REQUEST_CODE = 12345;

    @Override
    public void onReceive(Context context, Intent intent) {
        Intent startServiceIntent = new Intent(context, ListenerService.class);
        context.startService(startServiceIntent);
    }
}

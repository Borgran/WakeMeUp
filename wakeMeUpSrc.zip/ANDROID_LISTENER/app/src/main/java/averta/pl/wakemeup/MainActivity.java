package averta.pl.wakemeup;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.util.Log;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private ConstraintLayout rootLayout = null;
    private TextView loggerTextView = null;
    private BroadcastReceiver messageReceiver = null;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        super.setContentView(R.layout.activity_main);
        this.rootLayout = (ConstraintLayout) findViewById(R.id.activity_main_root);
        this.loggerTextView = (TextView) findViewById(R.id.loggerTextView);
        this.loggerTextView.setText("");

        this.initMessageReceiver();

        this.log("Listener started...");

        scheduleAlarm();
    }

    public void log(String msg) {
        if (this.loggerTextView == null) {
            Log.i("MainActivity.log", "NPE");
            return;
        }

        String dateFormatted = DateFormat.format("dd-MM-yyyy hh:mm:ss", new Date()).toString();

        String text = "";
        text = this.loggerTextView.getText().toString().trim();
        if (!text.isEmpty()) {
            text += "\n";
        }
        text += dateFormatted + ": " + msg;

        String[] lines = text.split("\n");
        if (lines != null && lines.length > 1000) {
            text = text.substring(text.indexOf("\n"));
        }

        this.loggerTextView.setText(text.toString());
    }

    public void scheduleAlarm() {
        long firstStart = System.currentTimeMillis(); // alarm is set right away
        long nextStartInterval = 60 * 1000;//every minute
        Intent intent = new Intent(getApplicationContext(), WolReceiver.class);
        final PendingIntent pIntent = PendingIntent.getBroadcast(this, WolReceiver.REQUEST_CODE, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        AlarmManager alarm = (AlarmManager) this.getSystemService(Context.ALARM_SERVICE);
        alarm.setRepeating(AlarmManager.RTC_WAKEUP, firstStart, nextStartInterval, pIntent);
        //alarm.setInexactRepeating(AlarmManager.RTC_WAKEUP, firstStart, AlarmManager.INTERVAL_FIFTEEN_MINUTES, pIntent);

        this.log("Scheduled interval "+nextStartInterval/1000+"s...");
    }

    public void cancelAlarm() {
        Intent intent = new Intent(getApplicationContext(), WolReceiver.class);
        final PendingIntent pIntent = PendingIntent.getBroadcast(this, WolReceiver.REQUEST_CODE,
                intent, PendingIntent.FLAG_UPDATE_CURRENT);
        AlarmManager alarm = (AlarmManager) this.getSystemService(Context.ALARM_SERVICE);
        alarm.cancel(pIntent);
    }

    private void initMessageReceiver() {
        this.messageReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String msg = intent.getStringExtra("msg");
                log(msg);
            }
        };
    }

    @Override
    public void onResume() {
        super.onResume();
        LocalBroadcastManager.getInstance(this).registerReceiver(messageReceiver, new IntentFilter("logging"));
    }

    @Override
    protected void onPause() {
        LocalBroadcastManager.getInstance(this).unregisterReceiver(messageReceiver);
        super.onPause();
    }
}
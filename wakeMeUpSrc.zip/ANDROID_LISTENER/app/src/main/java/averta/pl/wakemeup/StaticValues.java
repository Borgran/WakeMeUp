package averta.pl.wakemeup;

public final class StaticValues {
    public final static int KILL_APP = 0;
    public final static int LOG = 1;
}

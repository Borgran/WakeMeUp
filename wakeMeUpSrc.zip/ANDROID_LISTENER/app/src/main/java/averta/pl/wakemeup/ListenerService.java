package averta.pl.wakemeup;

import android.app.IntentService;
import android.content.Intent;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.legacy.content.WakefulBroadcastReceiver;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.AsyncHttpResponseHandler;
import com.loopj.android.http.SyncHttpClient;

import java.nio.charset.StandardCharsets;

import cz.msebera.android.httpclient.Header;

public class ListenerService extends IntentService {

    private static final String SERVER = "https://[YOUR SERVER ADDRESS HERE]/server.php";
    private final AsyncHttpClient aClient = new SyncHttpClient();

    public ListenerService() {
        super("ListenerService");
    }

    private void log(String msg) {
        Log.i("ListenerService", msg);

        Intent intent = new Intent("logging");
        intent.putExtra("msg", msg);
        LocalBroadcastManager.getInstance(this).sendBroadcast(intent);
    }

    @Override
    protected void onHandleIntent(@Nullable Intent intent) {
        aClient.get(this, SERVER, new AsyncHttpResponseHandler() {
            @Override
            public void onSuccess(int statusCode, Header[] headers, byte[] responseBody) {
                String result = new String(responseBody, StandardCharsets.UTF_8);

                if (!result.isEmpty() && !result.contains("OK")) {
                    SendWol sw = new SendWol();
                    boolean isSuccess = sw.callMany(result);

                    log("Results: "+isSuccess+" for "+result);
                } else {
                    log("Nothing to do...");
                }

            }

            @Override
            public void onFailure(int statusCode, Header[] headers, byte[] responseBody, Throwable error) {
                String result = (responseBody == null ? "" : new String(responseBody, StandardCharsets.UTF_8));
                log("Failed http connection to server! "+result);
            }
        });

        // Release the wake lock provided by the WakefulBroadcastReceiver.
        if (intent != null) {
            WakefulBroadcastReceiver.completeWakefulIntent(intent);
        }
    }
}